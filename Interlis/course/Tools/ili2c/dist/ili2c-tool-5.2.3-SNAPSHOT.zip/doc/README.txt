ili2c - The INTERLIS Compiler

License
ili2c is licensed under the LGPL (Lesser GNU Public License).

System Requirements

For the current version of ili2c, you will need a JRE (Java Runtime Environment) installed on your system, version 1.6.0 or later.
The JRE (Java Runtime Environment) can be downloaded for free from the Website http://www.java.com/ .

Installing ili2c

To install ili2c, choose a directory and extract the distribution file there. 

Running ili2c

There is currently no launcher. ili2c can be started with

java -jar ili2c.jar [options]

ili2c includes a little helper to create and maintain model repositories. See the help on the command line:

java -cp ili2c.jar ch.interlis.ilirepository.MakeIliModelsXml --help
