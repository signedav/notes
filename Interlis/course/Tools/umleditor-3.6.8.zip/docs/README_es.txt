UML-Editor - Editor de UML / INTERLIS

Licencia
Uml-Editor está licenciado bajo la LGPL (Lesser GNU Public License).


Configuración del sistema
Para ejecutar el Editor de UML, debe instalarse en su sistema el entorno de ejecución JAVA (JRE) versión 1.6 o una versión más reciente.
Una versión gratuita del entorno de tiempo de ejecución JAVA (JRE) está disponible en el sitio web http://www.java.com/.

Instalación
Para instalar el editor UML, extraiga el archivo ZIP en un nuevo directorio.

¿Cómo ejecutarlo?
Para iniciar Uml-Editor, escriba el siguiente comando en el indicador de línea  de comandos

java -jar umleditor.jar

