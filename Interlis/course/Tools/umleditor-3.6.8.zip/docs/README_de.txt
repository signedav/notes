UML-Editor - Der UML-INTERLIS-Editor

Lizenz
Der UML-Editor ist lizensiert unter der LGPL (Lesser GNU Public License).

System Anforderungen
Um die aktuelle Version des UML-Editors auszuführen, muss die JAVA-Laufzeitumgebung (JRE) Version 1.6 oder neuer auf Ihrem System installiert sein.
Die JAVA-Laufzeitumgebung (JRE) können Sie auf der Website http://www.java.com/ gratis beziehen.

Installation
Um den UML-Editor zu installieren, entpacken Sie die ZIP-Datei in ein neues Verzeichnis.

Ausführen
Um den UML-Editor auszuführen, geben Sie auf der Kommandozeile folgendes Kommando ein

java -jar umleditor.jar [options]
java -Duser.language=FR -jar umleditor.jar

Kommentare/Anregungen
Bitte senden Sie Kommentare an ce@eisenhutinformatik.ch.
